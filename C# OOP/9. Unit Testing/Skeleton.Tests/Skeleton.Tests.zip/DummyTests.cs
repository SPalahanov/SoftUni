﻿using System;
using System.Reflection.Metadata.Ecma335;
using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        private Dummy dummy;
        private int experience = 10;

        [SetUp]
        public void SetUp()
        {
            dummy = new Dummy(20, experience);
        }
        
        [Test]
        public void DummyShouldBeCreatedCorrectly()
        {
            int expectedHealth = 20;

            Assert.AreEqual(expectedHealth, dummy.Health);
        }

        [Test]
        public void DummyTakeAttackMethodShouldBeWorkCorrectly()
        {
            int expectedHealth = 15;

            dummy.TakeAttack(5);

            int actualHealth = dummy.Health;

            Assert.AreEqual(expectedHealth, dummy.Health);
        }

        [Test]
        public void DummyTakeAttackMethodShouldThrowExceptionIfDummyIsDead()
        {
            dummy = new Dummy(0, experience);

            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(()
                => dummy.TakeAttack(20));

            Assert.AreEqual("Dummy is dead.", exception.Message);
        }

        //[Test]
        //public void When_Attacked_ShouldDecreaseHealth()
        //{
        //    int attackPoints = 3;
        //    dummy.TakeAttack(attackPoints);

        //    Assert.That(dummy.Health, Is.EqualTo(dummy.Health - attackPoints), "Dummy doesn't loose health when attacked");
        //}

        //[Test]
        //public void When_HealthIsPositive_ShouldBeAlive()
        //{
        //    Assert.That(dummy.IsDead(), Is.EqualTo(false));
        //}

        //[Test]
        //public void When_HealthIsZero_ShouldBeDead()
        //{
        //    dummy = new Dummy(0, experience);
        //    Assert.That(dummy.IsDead(), Is.EqualTo(true));
        //}

        //[Test]
        //public void When_HealthIsNegative_ShouldBeDead()
        //{
        //    Assert.That(deadDummy.IsDead(), Is.EqualTo(true));
        //}

        [Test]
        public void DummyIsDead()
        {
            dummy.TakeAttack(20);

            bool expectedResult = true;

            Assert.AreEqual(expectedResult, dummy.IsDead());
        }

        [Test]
        public void DummyGiveExperienceMethodShouldBeWorkCorrectly()
        {
            int expectedResult = 0;

            Assert.AreEqual(expectedResult, new Dummy(0, 0).GiveExperience());

            //Assert.That(() => dummy.GiveExperience(), Throws.InvalidOperationException);

        }

        [Test]
        public void DummyGiveExperienceMethodShouldThrowExceptionIfDummyIsNotDead()
        {
            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(()
                => dummy.GiveExperience());

            Assert.AreEqual("Target is not dead.", exception.Message);
        }

        //[Test]
        //public void When_Dead_ShouldGiveExperience()
        //{
        //    Assert.That(deadDummy.GiveExperience(), Is.EqualTo(experience));
        //}

        //[Test]
        //public void When_AliveGiveExperience_ShouldThrow()
        //{
        //    Assert.That(() => { dummy.GiveExperience(); }, Throws.InvalidOperationException.With.Message.EqualTo("Target is not dead."));
        //}
    }
    
}