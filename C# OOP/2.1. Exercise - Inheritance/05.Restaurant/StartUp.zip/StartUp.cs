﻿namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Coffee cofe = new Coffee("Espresso", 45);
            
            //Console.WriteLine(cofe);
        }
    }
}