﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingSpree
{
    public class ExceptionMessages
    {
        public const string NameEmpty = "Name cannot be empty";
        public const string MoneyNegative = "Money cannot be negative";
    }
}
