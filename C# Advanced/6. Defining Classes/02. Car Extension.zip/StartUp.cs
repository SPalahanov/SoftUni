﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            car.Make = "VW";
            car.Model = "Golf";
            car.Year = 2006;
            car.FuelQuantity = 200;
            car.FuelConsumption = 5;

            car.Drive(20);

            Console.WriteLine(car.WhoAmI());
        }
    }
}