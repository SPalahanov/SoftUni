﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheRace
{
    public class Race
    {
        public Race(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Data = new List<Racer>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public List<Racer> Data { get; set; }

        public void Add(Racer Racer)
        {
            if (Data.Count < Capacity)
            {
                Data.Add(Racer);
            }
        }

        public bool Remove(string name) => Data.Remove(Data.FirstOrDefault(d => d.Name == name));

        public Racer GetOldestRacer() => Data.FirstOrDefault(Data.MaxBy(d => d.Age));

        public Racer GetRacer(string name) => Data.FirstOrDefault(d => d.Name == name);

        public Racer GetFastestRacer() => Data.FirstOrDefault(Data.MinBy(d => d.Car.Speed));

        public int Count => Data.Count;

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Racers participating at {Name}");

            foreach (var racer in Data)
            {
                sb.AppendLine(racer.ToString());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
