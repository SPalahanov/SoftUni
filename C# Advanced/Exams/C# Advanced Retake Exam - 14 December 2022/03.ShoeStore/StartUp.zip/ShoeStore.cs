﻿using System.Text;
using System.Threading.Channels;

namespace ShoeStore
{
    public class ShoeStore
    {
        private readonly List<Shoe> Shoes;
        public string Name { get; }
        public int StorageCapacity { get; }

        public ShoeStore(string name, int storageCapacity)
        {
            Name = name;
            StorageCapacity = storageCapacity;
            Shoes = new List<Shoe>();
        }

        public int Count => Shoes.Count;

        public string AddShoe(Shoe shoe)
        {
            if (Count < StorageCapacity)
            {
                Shoes.Add(shoe);
                return $"Successfully added {shoe.Type} {shoe.Material} pair of shoes to the store.";
            }
            else
            {
                return "No more space in the storage room.";
            }
        }

        public int RemoveShoes(string material)
        {
            int removedCount = Shoes.RemoveAll(shoe => shoe.Material.Equals(material, StringComparison.OrdinalIgnoreCase));
            return removedCount;
        }

        public List<Shoe> GetShoesByType(string type)
        {
            return Shoes.Where(shoe => shoe.Type.Equals(type, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public Shoe GetShoeBySize(double size)
        {
            return Shoes.FirstOrDefault(shoe => shoe.Size == size);
        }

        public string StockList(double size, string type)
        {
            var matchingShoes = Shoes.Where(shoe =>
                shoe.Size == size && shoe.Type.Equals(type, StringComparison.OrdinalIgnoreCase)).ToList();

            if (matchingShoes.Count > 0)
            {
                string stockList = $"Stock list for size {size} - {type} shoes:{Environment.NewLine}";
                stockList += string.Join(Environment.NewLine, matchingShoes);
                return stockList;
            }
            else
            {
                return "No matches found!";
            }
        }

    }
}